#include <stdio.h>
int main() {
    printf("Wrong line 1\n");
    printf("Expected line 2\n");
    printf("Wrong line 3\n");
    printf("Wrong line 4\n");
    printf("Expected line 5\n");
    printf("Expected line 6\n");
    printf("Expected line 7\n");
    printf("Expected line 8\n");
    printf("Expected line 9\n");
    printf("Expected line 10\n");
    printf("Wrong line 11\n");
    printf("Wrong line 12\n");
    printf("Expected line 13\n");
    printf("Wrong line 14\n");
    printf("Expected line 15\n");
    printf("Wrong line 16\n");
    printf("Wrong line 17\n");
    printf("Wrong line 18\n");
    printf("Wrong line 19\n");
    printf("Expected line 20\n");
    return 0;
}
